import matplotlib.pyplot as plt
import numpy as np
import os.path as os

#sets width and sets the directory
width = 0.5 
directory = os.dirname(os.abspath(__file__))

#imports data files
filename = os.join(directory, 'DataFile.csv')
filename1 = os.join(directory, 'lalalala.csv')

#interprets the data
datafile = open(filename,'r')
datafile1 = open(filename1,'r')
data = datafile.readlines()
data1 = datafile1.readlines()

#setting the list for each category
cases = []
state = []      
year1 = []
laws = []   

#adds to the lists for each axes taking data from the files
for line in data[0:]:
    numstate,numcases = line.split(',')
    state.append(numstate)
    cases.append(int(numcases))

#adds to the lists for each axes taking data from the files
for line in data1[0:]:
    numStates1, numlaws = line.split(',')
    year1.append(numStates1)
    laws.append(int(numlaws))

#sets the value as an integer to let the computer the range of the graph
number = np.arange(len(state)) 
number1 = np.arange(len(year1))

#creates the graph and sets the x and y axis
fig, ax  = plt.subplots(figsize = (8,10))
plt.bar(number, cases,width, align='center',)
plt.xticks(number,state, rotation = 'vertical')
plt.ylabel('Court Cases')
plt.xlabel('Year')
plt.title('Number of contested cases')
plt.show()

#creates the graph and sets the x and y axis
fig1, ax1  = plt.subplots(figsize = (8,10))
plt.bar(number1, laws,width, align='center',)
plt.xticks(number, year1,  rotation = 'vertical')
plt.ylabel('Number')
plt.xlabel('Year')
plt.title('NUmber of Luxary Cars')
plt.show()